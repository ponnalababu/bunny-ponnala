# Spring-boot-insurance-management-platform
Here I'm uploading insurance management project this is real time project which is based on policy.

Project Name: Insurance Management Platform

Language Used: Core-Java, Jdbc, Spring-Data-Jpa, Sql, with spring boot framework.
Database:MySQL with mysql-workbench-application
Teasting-Tool: Post-Man-API
IDE-Tool:STS(spring-tool-suite)
Repository:Github

Description:In this project I have created three classes as mentioned Claim,Client,InsurancePolicy.
There is a mapping between (InsurancePolicy to client) and (InsurancePolicy to claim)

I have created all the controller for those three classes now you can find the controller url below.


For Client First You have to run your spring boot application right click on your project and click on runspringboot application once the server started then open postman api and paste this 
url and change the port according to your server running port.
